/**
 * MyDrone
 * @constructor
 */

var degToRad = Math.PI / 180.0;
 
function MyDrone(scene,x,y,z,angle) 
 {
 	CGFobject.call(this,scene);
	
	this.x=x;
	this.y=y;
	this.z=z;
	this.angle=angle;
	
	this.initBuffers();

};

var a = 3;
var b = a/10;

MyDrone.prototype = Object.create(CGFobject.prototype);
MyDrone.prototype.constructor=MyDrone;

MyDrone.prototype.rotateRight = function()
{
	this.angle += a;
};

MyDrone.prototype.rotateLeft = function()
{
	this.angle -= a;
};

MyDrone.prototype.moveFoward = function()
{
	this.x += Math.sin(degToRad * this.angle)* b;
	this.z +=  Math.cos(degToRad * this.angle)* b;
};

MyDrone.prototype.moveBackwards= function()
{
	this.x -= Math.sin(degToRad * this.angle)* b;
	this.z -=  Math.cos(degToRad * this.angle)* b;
};

MyDrone.prototype.moveUp = function()
{
	this.y += b;
};

MyDrone.prototype.moveDown = function()
{
	this.y -= b;
};

MyDrone.prototype.initBuffers = function ()
 {
	this.vertices = [
            0.5, 0.3, 0,
            -0.5, 0.3, 0,
            0, 0.3, 2,
            ];

	this.indices = [
            0, 1, 2, 
			2,1,0,
			];
		
	this.primitiveType=this.scene.gl.TRIANGLES;
	
	/*this.normals = [
			0,0,1,
			0,0,1,
			0,0,1,
			0,0,1
			];*/
	
	
			
	this.initGLBuffers();
};